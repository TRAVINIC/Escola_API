const express = require('express');

const categoriaModel = require('../model/categoriaModel');

// Gerenciador de rotas
const router = express.Router();

// Rota de inserção de categoria (POST)
router.post('/categoria/inserir', (req, res) => {
    const nome_categoria = req.body.nome_categoria;

    categoriaModel.create({ nome_categoria })
        .then(() => {
            return res.status(201).json({
                errorStatus: false,
                messageStatus: 'Categoria inserida com sucesso'
            });
        })
        .catch((error) => {
            return res.status(500).json({
                errorStatus: true,
                messageStatus: error.message
            });
        });
});

// Rota de seleção de categoria (GET)
router.get('/categoria/selecionar', (req, res) => {
    categoriaModel.findAll()
        .then((categorias) => {
            res.json(categorias);
        })
        .catch((error) => {
            return res.status(500).json({
                errorStatus: true,
                messageStatus: error.message
            });
        });
});

// Rota de alteração de categoria (PUT)
router.put('/categoria/alterar', (req, res) => {
    const id = req.body.id;
    const nome_categoria = req.body.nome_categoria;

    categoriaModel.update({ nome_categoria }, { where: { id } })
        .then(() => {
            return res.status(200).json({
                errorStatus: false,
                messageStatus: 'Categoria alterada com sucesso'
            });
        })
        .catch((error) => {
            return res.status(500).json({
                errorStatus: true,
                messageStatus: error.message
            });
        });
});

// Rota de exclusão de categoria (DELETE)
router.delete('/categoria/excluir/:id', (req, res) => {
    const id = req.params.id;

    categoriaModel.destroy({ where: { id } })
        .then(() => {
            return res.status(200).json({
                errorStatus: false,
                messageStatus: 'Categoria excluída com sucesso'
            });
        })
        .catch((error) => {
            return res.status(500).json({
                errorStatus: true,
                messageStatus: error.message
            });
        });
});

module.exports = router;