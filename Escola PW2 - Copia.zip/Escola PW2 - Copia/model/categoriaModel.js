// Importando o Sequelize e a conexão com o banco de dados
const Sequelize = require('sequelize');
const connection = require('../database/database');

// Definindo o modelo da tabela Turmas
const Turma = connection.define(
    'turmas', // Nome da tabela no banco de dados
    {
        // Coluna para o nome da turma
        nome_turma: {
            type: Sequelize.STRING,
            allowNull: false,
            validate: {
                // Verifica se o nome da turma não está vazio
                notEmpty: {
                    msg: "O nome da turma não pode ser vazio."
                },
                // Verifica se o nome da turma tem no mínimo 3 caracteres
                len: {
                    args: [3, 255],
                    msg: "O nome da turma deve ter no mínimo 3 caracteres."
                }
            }
        }
    },
    {
        // Opções adicionais do modelo
        timestamps: false, // Desabilita os campos createdAt e updatedAt
        underscored: true, // Utiliza o padrão snake_case para os nomes das colunas
        charset: 'utf8', // Define o charset da tabela como UTF-8
        collate: 'utf8_general_ci' // Define a collation da tabela como utf8_general_ci
    }
);

// Sincroniza o modelo com o banco de dados, criando a tabela se não existir
// Turma.sync({force: true}); // Descomente esta linha para forçar a criação da tabela, apagando-a se já existir

module.exports = Turma;